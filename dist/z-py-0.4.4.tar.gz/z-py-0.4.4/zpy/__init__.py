__author__ = 'zhenghy'
__all__ = ['awm','astr','anum','nowf','amkdir','script']

from zpy.awm import *
